#!/bin/bash
#
################################################################################################
################################################################################################
# Implementando sakai 10.7
# 
# Requisitos de la implementacion
# Jdk 8u92
# apache-tomcat-8.0.36
# sakai-bin-10.7
# aptitude install mysql-server -y
#
###########################################################################################################################################
###########################################################################################################################################
#################################################### Configuracion preliminar de sakai ####################################################
###########################################################################################################################################
###########################################################################################################################################

###################################################
############### Variables del script ##############
###################################################
Particion=;
usuario=;

sakai_properties=;

basedatos=;
usuariobd=;
contrasena=;

# variables de puertos
spuerto=;
puerto=;
epuerto=;

# determinando usuario y particion
read -p "Por favor ingrese la particion a utilizar: " Particion;
read -p "ingrese el usuario que ejecutará sakai: " usuario;
echo "Utilizando " $Particion " como usuario " $usuario " para configurar sakai..."

# Determinando la base de datos, usuario y contraseña de usuario de base de datos mysql
read -p "Ingrese el nombre de la base de datos para crear: " basedatos;
read -p "Tambien el usuario que sera dueño de la base de datos: " usuariobd;
read -p "Digite una contraseña de usuario" contrasena;
echo "La base de datos " $basedatos " y el usuario " $usuariobd " serán establecidos."
# Particion=/sakai0;
# usuario=;

# Determinando los puertos de recepcion y escuchar de sakai
read -p "Ingrese el puerto conector por el cual sakai se comunicará con el mundo: " puerto;
 read -p "tambien el puerto de apagado de la aplicacion: " spuerto;
 read -p "y el puerto de entrada de peticiones tomcat: " epuerto;
# todas las impresiones y datos deben ir a un servidor para guardar las configuraciones por empresa.
echo "los puertos son: " "conector: " $puerto " | puerto de apagado: " $spuerto " | puerto de entrada tomcat: " $epuerto

cd ${Particion};

###################################################
############### Descargas necesarias ##############
###################################################
echo "Descargando archivos necesarios..."

# Descarga de binarios sakai 10.7
# wget http://BaseDataSourceurce.sakaiproject.org/release/10.7/artifacts/sakai-bin-10.7.tar.gz.MD5;
wget http://source.sakaiproject.org/release/10.7/artifacts/sakai-bin-10.7.tar.gz;
#md5sum -c sakai-bin-10.7.tar.gz.md5; # !!! comprobar comando

# JDK 8u92
wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie" http://download.oracle.com/otn-pub/java/jdk/8u92-b14/jdk-8u92-linux-x64.tar.gz;

# tomcat 8.0.36
wget http://www-us.apache.org/dist/tomcat/tomcat-8/v8.0.36/bin/apache-tomcat-8.0.36.tar.gz https://www.apache.org/dist/tomcat/tomcat-8/v8.0.36/bin/apache-tomcat-8.0.36.tar.gz.sha1;
sha1sum -c apache-tomcat-8.0.36.tar.gz.sha1;

# MySql 5.1.39
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.39.tar.gz;
tar xzvf mysql-connector-java-5.1.39.tar.gz;

###################################################
########### Configuraciones preliminares ##########
###################################################
echo "Configurando Jdk 8..."
# instalacion de java 8
tar xzvf jdk-8u92-linux-x64.tar.gz; # Extraer la carpeta de JDK
update-alternatives --install /usr/bin/java java /sakai/jdk1.8.0_92/bin/java 1110; # actualizar version de JAVA para enlazarla al sistema
update-alternatives --install /usr/bin/javac javac /sakai/jdk1.8.0_92/bin/javac 1110; # Actualizar version de JAVAC ......

echo "Desplegando el servidor tomcat..."
# instalacion de tomcat
tar xzvf apache-tomcat-8.0.36.tar.gz; # extraccion de la carpeta
ln -nsf apache-tomcat-8.0.36 tomcat; # enlace simbolico para implementar sakai desde aqui.

###################################################
############ Variables del entorno ################
###################################################
echo "Asignando variables del entorno..."
sed -i "$a export JAVA_HOME=`echo $Particion`/jdk1.8.0_92" /home/${usuario}/.bashrc;
sed -i "$a export CATALINA_HOME=`echo $Particion`/tomcat" /home/${usuario}/.bashrc;
sed -i "$a export PATH=${PATH}:${JAVA_HOME}/bin/:${CATALINA_HOME}/bin" /home/${usuario}/.bashrc;

# Variables de entorno maven agregadas por defecto 
# en la instalacion  por aptitude
# MAVEN_OPTS
sed -i "$a export MAVEN_OPTS='-Xms512m -Xmx1024m -XX:PermSize=256m -XX:MaxPermSize=512m -Djava.util.Arrays.useLegacyMergeSort=true'" /home/${usuario}/.bashrc;

# Actualiza las variables del entorno
cd /home/${usuario};
source .bashrc;

###################################################
############## Archivo setenv.sh ##################
###################################################
echo "configurando setenv.sh"
# mejorar velocidad de inicio tomcat
touch ${Particion}/tomcat/bin/setenv.sh;
cat > ${Particion}/tomcat/bin/setenv.sh <<EOF
>linea
>liena
EOF
# para ubicar archivo *.properties en otra ubicacion
# para iniciar sakai con datos de muestra:  -Dsakai.demo=true
# -Dsakai.home=/path/to/desired/sakai/home/ para ubicar el archivo sakai.properties en otro lugar
sed -i '1c #! /bin/sh' ${Particion}/tomcat/bin/setenv.sh;
sed -i "2c export JAVA_OPTS='-server -Xms512m -Xmx1024m -XX:PermSize=128m -XX:NewSize=192m -XX:MaxNewSize=384m -Djava.awt.headless=true -Dhttp.agent=Sakai -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Dsun.lang.ClassLoader.allowArraySyntax=true -Dsun.lang.ClassLoader.allowArraySyntax=true -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Dhttp.agent=Sakai -Duser.language=es -Duser.region=CO'" ${Particion}/tomcat/bin/setenv.sh;

# export JAVA_OPTS='-server -Xms512m -Xmx1024m -XX:PermSize=128m -XX:NewSize=192m -XX:MaxNewSize=384m -Djava.awt.headless=true -Dhttp.agent=Sakai -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Dsun.lang.ClassLoader.allowArraySyntax=true'
# export JAVA_OPTS="-server -Xmx1028m -XX:MaxMetaspaceSize=512m -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Djava.awt.headless=true -Dcom.sun.management.jmxremote"

echo "borrando ejemplos de aplicaciones del servidor tomcat"
# Borrar webapps
rm -rf ${Particion}/tomcat/webapps/*;


###################################################
############## Archivo server.xml #################
###################################################
echo "Agregando codificacion UTF-8 a server.xml"
# <Connector port="8080" URIEncoding="UTF-8" ... 
# Esta opcion es insertada antes de la linea 70
sed -i "22c <Server port=\"`echo $spuerto`\" shutdown=\"SHUTDOWN\">" ${Particion}/tomcat/conf/server.xml; # linea 22 puerto de apagado de la aplicacion
sed -i "69c \    <Connector port=\"`echo $puerto`\" protocol=\"HTTP/1.1\"" ${Particion}/tomcat/conf/server.xml; # puerto del conector de la aplicacionnes
sed -i "92c \    <Connector port=\"`echo $epuerto`\" protocol=\"AJP/1.3\" redirectPort=\"8443\" />" # linea 92 puerto de entrada de peticiones tomcat
sed -i '70i \\t       URIEncoding="UTF-8"' ${Particion}/tomcat/conf/server.xml; 

###################################################
########## Archivo catalina.properties ############
###################################################
echo "Configurando el archivo catalina.properties"
# insercion de propiedades de tomcat en las lineas 
# 53, 71 y 90 respectivamente.
sed -i '53c common.loader="${catalina.base}/lib","${catalina.base}/lib/*.jar","${catalina.home}/lib","${catalina.home}/lib/*.jar","${catalina.base}/common/classes/","${catalina.base}/common/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;
sed -i '71c server.loader="${catalina.base}/server/classes/","${catalina.base}/server/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;
sed -i '90c shared.loader="${catalina.base}/shared/classes/","${catalina.base}/shared/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;

###################################################
############## Archivo context.xml ################
###################################################
echo "incrementando la velocidad de inicio del servidor"
sed -i '29a \    <JarScanner>\n \t<JarScanFilter defaultPluggabilityScan="false" />\n    </JarScanner>' ${Particion}/tomcat/conf/context.xml;

###################################################
############## Carpetas necesarias ################
###################################################
echo "Agregando carpetas necesarias"
# Para el funcionamiento de sakai en tomcat.
mkdir -p ${Particion}/tomcat/shared/classes ${Particion}/tomcat/shared/lib ${Particion}/tomcat/common/classes ${Particion}/tomcat/common/lib ${Particion}/tomcat/server/classes ${Particion}/tomcat/server/lib;

###################################################
############ Configurar driver mysql ##############
###################################################
echo "Agregando el conector de base de datos mysql"
# copiando el *.jar que permite la conexion entre
# sakai 10.7 y mysql.
cp ${Particion}/mysql-connector-java-5.1.39/mysql-connector-java-5.1.39-bin.jar ${Particion}/tomcat/lib/mysql-connector-java-5.1.39-bin.jar;


###################################################
######## Implementando e iniciando sakai 10.7 #####
###################################################
echo "descomprimiendo archivos binarios de sakai"
# descomprimiendo binarios sakai
mv ${Particion}/sakai-bin-10.7.tar.gz ${Particion}/tomcat/sakai-bin-10.7.tar.gz;
cd tomcat;
tar xzvf sakai-bin-10.7.tar.gz;


###################################################
############### sakai.properties ###############    ###
###################################################
echo "Configurando el archivo sakai.properties..."
###################################################
# 1.0 crear archivo sakai.properties ##############
touch ${Particion}/tomcat/sakai/sakai.properties;
# Una variable para simplicidad
sakai_properties= ${Particion}/tomcat/sakai/sakai.properties;

#cp ${Particion}/sakai/config/configuration/bundles/src/bundle/org/sakaiproject/config/bundle/default.sakai.properties ${Particion}/tomcat/sakai/sakai.properties;

###################################################
# 2.0 Configure home page tool set per site #######
sed -i "2709c wsetup.home.toolids.count=5" $sakai_properties;
sed -i "2710c wsetup.home.toolids.1=sakai.iframe.site" $sakai_properties;
sed -i "2711c wsetup.home.toolids.2=sakai.synoptic.announcement" $sakai_properties;
sed -i "2712c wsetup.home.toolids.3=sakai.summary.calendar" $sakai_properties;
sed -i "2713c wsetup.home.toolids.4=sakai.synoptic.messagecenter" $sakai_properties;
sed -i "2714c wsetup.home.toolids.5=sakai.synoptic.chat" $sakai_properties;
sed -i "2715c wsetup.home.toolids.course.count=5" $sakai_properties;
sed -i "2716c wsetup.home.toolids.course.1=sakai.iframe.site" $sakai_properties;
sed -i "2717c wsetup.home.toolids.course.2=sakai.synoptic.announcement" $sakai_properties;
sed -i "2718c wsetup.home.toolids.course.3=sakai.summary.calendar" $sakai_properties;
sed -i "2719c wsetup.home.toolids.course.4=sakai.synoptic.messagecenter" $sakai_properties;
sed -i "2720c wsetup.home.toolids.course.5=sakai.synoptic.chat" $sakai_properties;

###################################################
# 3.0 Work site setup group helper ################


###################################################
# 4.0 Session timeout warning #####################
sed -i "1120c timeoutDialogEnabled=true" $sakai_properties;
sed -i "1123c timeoutDialogWarningSeconds=600" $sakai_properties;

###################################################
# 5.0 Configure email #############################


###################################################
# 6.0 Configure logging ###########################


###################################################
# 7.0 Managing temporary files ####################


###################################################
# 6.1 Configure database ##########################
sed -i "311c username@javax.sql.BaseDataSource=`echo $usuariobd`" $sakai_properties;
sed -i "312c password@javax.sql.BaseDataSource=`echo $contrasena`" $sakai_properties;
sed -i "328c vendor@org.sakaiproject.db.api.SqlService=mysql" $sakai_properties;
sed -i "329c driverClassName@javax.sql.BaseDataSource=com.mysql.jdbc.Driver" $sakai_properties;
sed -i "330c hibernate.dialect=org.hibernate.dialect.MySQL5InnoDBDialect" $sakai_properties;
sed -i "331c url@javax.sql.BaseDataSource=jdbc:mysql://127.0.0.1:3306/`echo $basedatos`?useUnicode=true&characterEncoding=UTF-8" $sakai_properties;
sed -i "332c validationQuery@javax.sql.BaseDataSource=select 1 from DUAL" $sakai_properties;
sed -i "333c defaultTransactionIsolationString@javax.sql.BaseDataSource=TRANSACTION_READ_COMMITTED" $sakai_properties;

###################################################
##### Ejecucion de script en servidor mysql #######
###################################################
echo "Creando la base de datos en MySql..."
# ref http://clubmate.fi/shell-script-to-create-mysql-database/

mysql -u root -p

# Functions
#ok() { echo -e '\e[32m'$1'\e[m'; } # Green

MYSQL=`which mysql`
 
Q1="create database ${basedatos} default character set utf8;"
Q2="grant all on ${basedatos}.* to ${usuariobd}@'localhost' identified by '${contrasena}';"
Q3="grant all on ${basedatos}.* to ${usuariobd}@'127.0.0.1' identified by '${contrasena}';"
Q4= "flush privileges;"

SQL="${Q1}${Q2}${Q3}${Q4}"
 
 
$MYSQL -u root -p -e "$SQL"

#ok "Database $1 and user $2 created with a password $3"



echo "Ajustando los permisos y propiedades de archivos..."
# Verificar permisos y propiedades
chown -R $usuario:$usuario ${Particion}/tomcat && chmod -R 775 ${Particion}/tomcat;
chown $usuario:$usuario -R ${Particion}/apache-tomcat-8.0.36/ && chmod -R 775 ${Particion}/apache-tomcat-8.0.36;

# Borrando archivos innecesarios
echo "Borrando archivos que no necesarios..."
rm -r jdk-8u92-linux-x64.tar.gz mysql-connector-java-5.1.39.tar.gz apache-tomcat-8.0.36.tar.gz sakai-bin-10.7.tar.gz apache-tomcat-8.0.36.tar.gz.sha1;


# arranque de la aplicacion
#cd ${Particion}/tomcat/bin;
#./startup.sh && tail -f ../logs/catalina.out;

echo "Listo.  ;)"
####################################################
# Referencias
# http://unix.stackexchange.com/questions/148967/how-to-use-a-shell-variable-inside-seds-s-command