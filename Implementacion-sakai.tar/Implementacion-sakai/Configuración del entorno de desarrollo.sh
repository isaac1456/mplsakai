#!/bin/sh


# Configuración del entorno de desarrollo


# JDK 8u92
wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie" http://download.oracle.com/otn-pub/java/jdk/8u92-b14/jdk-8u92-linux-x64.tar.gz;

# mysql-server
aptitude install mysql-server -y;
# maven
aptitude install maven -y;

# git
aptitude install git -y;

# Tomcat 8.0.32 
wget http://archive.apache.org/dist/tomcat/tomcat-8/v8.0.32/bin/apache-tomcat-8.0.32.tar.gz;
wget http://archive.apache.org/dist/tomcat/tomcat-8/v8.0.32/bin/apache-tomcat-8.0.32.tar.gz.asc;
wget http://archive.apache.org/dist/tomcat/tomcat-8/v8.0.32/bin/apache-tomcat-8.0.32.tar.gz.md5;
wget http://archive.apache.org/dist/tomcat/tomcat-8/v8.0.32/bin/apache-tomcat-8.0.32.tar.gz.sha1;

# MySql Connector 5.1.39 
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.39.tar.gz;

# Eclipsse jee mars 2
# wget http://mirror.cc.columbia.edu/pub/software/eclipse/technology/epp/downloads/release/mars/2/eclipse-jee-mars-2-linux-gtk-x86_64.tar.gz -P ${entorno-ide}
wget http://mirror.cc.columbia.edu/pub/software/eclipse/technology/epp/downloads/release/mars/2/eclipse-jee-mars-2-linux-gtk-x86_64.tar.gz;

# lombok for eclipse
wget https://projectlombok.org/downloads/lombok.jar;

# Resource bundle editor
wget https://sourceforge.net/settings/mirror_choices?projectname=eclipse-rbe&filename=Eclipse%203.x/0.8.0/ResourceBundleEditor_v0.8.0.zip;

# sakai source
git clone https://github.com/sakaiproject/sakai.git;
#cd sakai && git checkout 11.0


# configuraciones del codigo fuente de sakai
# mvn eclipse:clean
# mvn eclipse:m2eclipse


# Referencias: 
# * https://confluence.sakaiproject.org/display/BOOT/Development+Environment+Setup+Walkthrough
# * http://stackoverflow.com/questions/1078524/how-to-specify-the-location-with-wget
# * http://archive.apache.org/dist/tomcat/tomcat-8/v8.0.32/bin/
# * https://projectlombok.org/
# * http://eclipse-rbe.sourceforge.net/




