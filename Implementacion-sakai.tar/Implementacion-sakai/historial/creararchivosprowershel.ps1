# http://ss64.com/ps/set-variable.html

set-variable -name libreria -value "D:\mpl\Mario-Roberto\Proyecto\Sakai\repositorios\Implementacion-sakai\funciones";
"#variables" > $libreria\variables.func;
"#logs" > $libreria\logs.func;
"#descargas" > $libreria\descargas.func;
"#configuraciones" > $libreria\configuraciones.func;
"#backups" > $libreria\backups.func;
"#plugins" > $libreria\plugins.func;
"#compilacion" > $libreria\compilacion.func;
"#ejecucion" > $libreria\ejecucion.func;
"#sakai-properties" > $libreria\sakai-properties.func;
"#plugins" > $libreria\plugins.func;


