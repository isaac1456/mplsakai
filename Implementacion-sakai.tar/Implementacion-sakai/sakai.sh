#! /bin/sh

###################################################
############### Implementacion de sakai ###########
###################################################

# llamado de funciones
. ./funciones/variables.func
. ./funciones/logs.func


. ./funciones/backups.func

echo `clear`
echo "Bienvenido a la Implementacion de sakai"
echo
echo
echo "Escoja una opcion: "
echo "1. Implementar sakai en tomcat"
echo "2. Limpiar el servidor de aplicaciones de tomcat"
echo "3. Realizar backup de sakai"
echo "4. Salir"

read opcion

while :
do
	case $opcion in
		1 )
			echo `clear`
			echo "Implementando sakai . . ....."

			### carga dSe funciones
			. ./funciones/descargas.func
			. ./funciones/plugins.func
			. ./funciones/conf.func
			. ./funciones/build.func
			. ./funciones/sakai-properties.func
			. ./funciones/ejecucion.func
			####################################

			setglobalvars
			

			if [ -d "$disco" ]; then
				crearlogs
				setvarsakai

				# Descargas de programas necesarios
				descargas

				#Configuraciones necesarias de archivos descargados
				conf_jdk
				conf_tomcat

				conf_cata_sh
				conf_setenv
				conf_xmls

				# Agregando usuario y base de datos mysql
				setmydb

			else
				echo  "La ruta al disco no se encuentra definida"
			fi

			

			echo `clear`
		;;

		2)
			echo `clear`
			echo "Limpiando el servidor de aplicaciones de tomcat . . ......"

			setglobalvars
			. ./funciones/clean.func

			dropmydb

			echo `clear`
			echo "Listo."
		;;

		3)
			echo `clear`
			echo "Realizando copias de seguridad de la información . . ......"
		;;

		4)
			echo `clear`
			echo "Fin......."
			break
		;;

		*)
			echo `clear`
			echo "Error, por favor digite una opcion valida"
		;;
	esac
done