#! /bin/bash
#
################################################################################################
################################################################################################
# Implementando sakai 10.7 desde el codigo fuente
# 
# Requisitos de la implementacion
# Jdk 7u80
# apache-tomcat-8.0.36
# sakai-bin-10.7
# aptitude install mysql-server -y
#
###########################################################################################################################################
###########################################################################################################################################
#################################################### Configuracion preliminar de sakai ####################################################
###########################################################################################################################################
###########################################################################################################################################

###################################################
############### Variables del script ##############
###################################################
Particion=;
usuario=;

sakai_properties=;

basedatos=;
usuariobd=;
contrasena=;

# variables de puertos
spuerto=;
puerto=;
epuerto=;
rpuerto=;

# determinando usuario y particion
read -p "Por favor ingrese la particion a utilizar: " Particion;
read -p "ingrese el usuario que ejecutará sakai: " usuario;
echo "Utilizando " $Particion " como usuario " $usuario " para configurar sakai..."

# Determinando la base de datos, usuario y contraseña de usuario de base de datos mysql
read -p "Ingrese el nombre de la base de datos para crear: " basedatos;
read -p "Tambien el usuario que sera dueño de la base de datos: " usuariobd;
read -p "Digite una contraseña de usuario: " contrasena;
echo "La base de datos " $basedatos " y el usuario " $usuariobd " serán establecidos."
# Particion=/sakai0;
# usuario=;

# Determinando los puertos de recepcion y escuchar de sakai
echo " no puertos 8080 8005 y 8009"
read -p "Ingrese el puerto conector por el cual sakai se comunicará con el mundo: " puerto;
read -p "tambien el puerto de apagado de la aplicacion: " spuerto;
read -p "y el puerto de entrada de peticiones tomcat: " epuerto;
read -p "y el puerto de redirección tomcat: " rpuerto;
# todas las impresiones y datos deben ir a un servidor para guardar las configuraciones por empresa.
echo "los puertos son: " "conector: " $puerto " | puerto de apagado: " $spuerto " | puerto de entrada tomcat: " $epuerto " | puerto redirección: " $rpuerto

mkdir ${Particion}/logs-implementacion;
cd ${Particion}/logs-implementacion;
touch git-sakai.log wget-jtm.log apt.log x-jdk.log x-tomcat.log x-mysql.log ins-sakai.log imp-sakai.log;
cd ${Particion};

###################################################
############### Descargas necesarias ##############
###################################################
echo "Descargando archivos necesarios..."
echo " "

# Aptitude de programas necesarios
echo "    Aptitude de programas necesarios"
echo " "
aptitude install maven mysql subversion -y > ${Particion}/logs-implementacion/apt.log; 

# Descarga de binarios del código fuente
echo "    Descarga de binarios del código fuente, sakai-10.7..."
echo " "
svn co https://source.sakaiproject.org/svn/sakai/tags/sakai-10.7/ sakai-10.7 > ${Particion}/logs-implementacion/git-sakai.log;

# JDK 8u92
echo "    Descargando JDK 7..."
echo " "
wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie" http://download.oracle.com/otn-pub/java/jdk/7u80-b15/jdk-7u80-linux-x64.tar.gz > ${Particion}/logs-implementacion/wget-jtm.log;

# tomcat 8.0.36
echo "     Descargando tomcat 8.0.36"
echo " "
wget http://www-us.apache.org/dist/tomcat/tomcat-8/v8.0.36/bin/apache-tomcat-8.0.36.tar.gz https://www.apache.org/dist/tomcat/tomcat-8/v8.0.36/bin/apache-tomcat-8.0.36.tar.gz.sha1;
sha1sum -c apache-tomcat-8.0.36.tar.gz.sha1 >> ${Particion}/logs-implementacion/wget-jtm.log;

# MySql 5.1.39
echo "     Descargando mysql jdbc 5.1.39"
echo " "
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.39.tar.gz >> ${Particion}/logs-implementacion/wget-jtm.log;
tar xzvf mysql-connector-java-5.1.39.tar.gz;

###################################################
########### Configuraciones preliminares ##########
###################################################
echo "Configurando Jdk 7..."
echo " "
# instalacion de java 7
tar xzvf jdk-7u80-linux-x64.tar.gz > ${Particion}/logs-implementacion/x-jdk.log; # Extraer la carpeta de JDK
update-alternatives --install /usr/bin/java java ${Particion}/jdk1.7.0_80/bin/java 1000; # actualizar version de JAVA para enlazarla al sistema Automatizar numero de prioridad java
update-alternatives --install /usr/bin/javac javac ${Particion}/jdk1.7.0_80/bin/javac 1000; # Actualizar version de JAVAC ...... Automatizar numero de prioridad java

echo "Desplegando el servidor tomcat..."
echo " "
# instalacion de tomcat
tar xzvf apache-tomcat-8.0.36.tar.gz > ${Particion}/logs-implementacion/x-tomcat.log; # extraccion de la carpeta
ln -nsf apache-tomcat-8.0.36 tomcat; # enlace simbolico para implementar sakai desde aqui.

###################################################
############ Variables del entorno ################
###################################################
echo "Asignando variables del entorno..."
echo " "

export JAVA_HOME=${Particion}/jdk1.7.0_80;
export CATALINA_HOME=${Particion}/tomcat;
export PATH=${PATH}:${JAVA_HOME}/bin/:${CATALINA_HOME}/bin;
export MAVEN_OPTS='-Xms512m -Xmx1024m -XX:PermSize=256m -XX:MaxPermSize=512m -Djava.util.Arrays.useLegacyMergeSort=true'


sed -i "17a # ----------------------------------------------------------------------------" ${Particion}/tomcat/bin/catalina.sh;
sed -i "18a # Configuring CATALNA_HOME and CATALINA_BASE variables" ${Particion}/tomcat/bin/catalina.sh;
sed -i "19a # ----------------------------------------------------------------------------" ${Particion}/tomcat/bin/catalina.sh;
sed -i "20a \ #" ${Particion}/tomcat/bin/catalina.sh;
sed -i "21a export CATALINA_HOME=`echo $Particion`/tomcat" ${Particion}/tomcat/bin/catalina.sh;
sed -i "22a export CATALINA_BASE=`echo $Particion`/tomcat" ${Particion}/tomcat/bin/catalina.sh;
sed -i "23a export JAVA_HOME=`echo $Particion`/jdk1.7.0_80" ${Particion}/tomcat/bin/catalina.sh;
sed -i "24a export PATH=${PATH}:${JAVA_HOME}/bin/:${CATALINA_HOME}/bin" ${Particion}/tomcat/bin/catalina.sh;



# Variables de entorno maven agregadas por defecto 
# en la instalacion  por aptitude
# MAVEN_OPTS
# sed -i "$a export MAVEN_OPTS='-Xms512m -Xmx1024m -XX:PermSize=256m -XX:MaxPermSize=512m -Djava.util.Arrays.useLegacyMergeSort=true'" /home/${usuario}/.bashrc;

# Actualiza las variables del entorno
# cd /home/${usuario};
# source .bashrc;

###################################################
############## Archivo setenv.sh ##################
###################################################
echo "configurando setenv.sh"
echo " "
# mejorar velocidad de inicio tomcat
touch ${Particion}/tomcat/bin/setenv.sh;
cat > ${Particion}/tomcat/bin/setenv.sh <<EOF
>linea
>liena
EOF
# para ubicar archivo *.properties en otra ubicacion
# para iniciar sakai con datos de muestra:  -Dsakai.demo=true
# -Dsakai.home=/path/to/desired/sakai/home/ para ubicar el archivo sakai.properties en otro lugar
sed -i '1c #! /bin/sh' ${Particion}/tomcat/bin/setenv.sh;
sed -i "2c export JAVA_OPTS='-server -Xms512m -Xmx1024m -XX:PermSize=128m -XX:MaxPermSize=512m -XX:NewSize=192m -XX:MaxNewSize=384m -Djava.awt.headless=true -Dhttp.agent=Sakai -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Dsun.lang.ClassLoader.allowArraySyntax=true -Duser.language=es -Duser.region=CO'" ${Particion}/tomcat/bin/setenv.sh;
           
echo "borrando ejemplos de aplicaciones del servidor tomcat"
# Borrar webapps
rm -rf ${Particion}/tomcat/webapps/*;


###################################################
############## Archivo server.xml #################
###################################################
echo "Agregando codificacion UTF-8 a server.xml"
echo " "
# <Connector port="8080" URIEncoding="UTF-8" ... 
# Esta opcion es insertada antes de la linea 70
sed -i "22c <Server port=\"`echo $spuerto`\" shutdown=\"SHUTDOWN\">" ${Particion}/tomcat/conf/server.xml; # linea 22 puerto de apagado de la aplicacion
sed -i "69c \    <Connector port=\"`echo $puerto`\" protocol=\"HTTP/1.1\"" ${Particion}/tomcat/conf/server.xml; # puerto del conector de la aplicacionnes
sed -i '70i \\t       URIEncoding="UTF-8"' ${Particion}/tomcat/conf/server.xml; 
sed -i "72c \               redirectPort=\"`echo $rpuerto`\" />" ${Particion}/tomcat/conf/server.xml;
sed -i "92c \    <Connector port=\"`echo $epuerto`\" protocol=\"AJP/1.3\" redirectPort=\"`echo $rpuerto`\" />" ${Particion}/tomcat/conf/server.xml; # linea 92 puerto de entrada de peticiones tomcat




###################################################
########## Archivo catalina.properties ############
###################################################
echo "Configurando el archivo catalina.properties"
echo " "
# insercion de propiedades de tomcat en las lineas 
# 53, 71 y 90 respectivamente.
sed -i '53c common.loader="${catalina.base}/lib","${catalina.base}/lib/*.jar","${catalina.home}/lib","${catalina.home}/lib/*.jar","${catalina.base}/common/classes/","${catalina.base}/common/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;
sed -i '71c server.loader="${catalina.base}/server/classes/","${catalina.base}/server/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;
sed -i '90c shared.loader="${catalina.base}/shared/classes/","${catalina.base}/shared/lib/*.jar"' ${Particion}/tomcat/conf/catalina.properties;

###################################################
############## Archivo context.xml ################
###################################################
echo "incrementando la velocidad de inicio del servidor"
echo " "
sed -i '29a \    <JarScanner>\n \t<JarScanFilter defaultPluggabilityScan="false" />\n    </JarScanner>' ${Particion}/tomcat/conf/context.xml;

###################################################
############## Carpetas necesarias ################
###################################################
echo "Agregando carpetas necesarias"
echo " "
# Para el funcionamiento de sakai en tomcat.
mkdir -p ${Particion}/tomcat/shared/classes ${Particion}/tomcat/shared/lib ${Particion}/tomcat/common/classes ${Particion}/tomcat/common/lib ${Particion}/tomcat/server/classes ${Particion}/tomcat/server/lib;

###################################################
############ Configurar driver mysql ##############
###################################################
echo "Agregando el conector de base de datos mysql"
echo " "
# copiando el *.jar que permite la conexion entre
# sakai 10.7 y mysql.
cp ${Particion}/mysql-connector-java-5.1.39/mysql-connector-java-5.1.39-bin.jar ${Particion}/tomcat/lib/mysql-connector-java-5.1.39-bin.jar;


####################################################
# Compilacion e implementacion sakai 10.7 a tomcat #
####################################################
echo "Compilacion e implementacion en curso ..."
echo " "
# Install the Sakai master project
cd ${Particion}/sakai-10.7/master;
mvn clean install > ${Particion}/logs-implementacion/ins-sakai.log;
# mvn clean install -Dmaven.test.skip=true sakai:deploy

# Install and deploy Sakai
cd ${Particion}/sakai-10.7;
mvn clean install sakai:deploy -Dmaven.tomcat.home=${Particion}/tomcat  -Djava.net.preferIPv4Stack=true -Dmaven.test.skip=true > ${Particion}/logs-implementacion/imp-sakai.log;
#-Dsakai.home=${Particion}/tomcat/sakai


###################################################
############### sakai.properties ###############    ###
###################################################
echo "Configurando el archivo sakai.properties..."
echo " "
###################################################
# 1.0 crear archivo sakai.properties ##############
mkdir ${Particion}/tomcat/sakai;
touch ${Particion}/tomcat/sakai/sakai.properties;
# Una variable para simplicidad
sakai_properties= ${Particion}/tomcat/sakai/sakai.properties;

cp ${Particion}/sakai-10.7/config/configuration/bundles/src/bundle/org/sakaiproject/config/bundle/default.sakai.properties ${Particion}/tomcat/sakai/sakai.properties;
chown $usuario ${Particion}/tomcat/sakai/sakai.properties;
chmod 775 ${Particion}/tomcat/sakai/sakai.properties;

###################################################
# 2.0 Configure home page tool set per site #######
sed -i "2709c wsetup.home.toolids.count=5" $sakai_properties;
sed -i "2710c wsetup.home.toolids.1=sakai.iframe.site" $sakai_properties;
sed -i "2711c wsetup.home.toolids.2=sakai.synoptic.announcement" $sakai_properties;
sed -i "2712c wsetup.home.toolids.3=sakai.summary.calendar" $sakai_properties;
sed -i "2713c wsetup.home.toolids.4=sakai.synoptic.messagecenter" $sakai_properties;
sed -i "2714c wsetup.home.toolids.5=sakai.synoptic.chat" $sakai_properties;
sed -i "2715c wsetup.home.toolids.course.count=5" $sakai_properties;
sed -i "2716c wsetup.home.toolids.course.1=sakai.iframe.site" $sakai_properties;
sed -i "2717c wsetup.home.toolids.course.2=sakai.synoptic.announcement" $sakai_properties;
sed -i "2718c wsetup.home.toolids.course.3=sakai.summary.calendar" $sakai_properties;
sed -i "2719c wsetup.home.toolids.course.4=sakai.synoptic.messagecenter" $sakai_properties;
sed -i "2720c wsetup.home.toolids.course.5=sakai.synoptic.chat" $sakai_properties;

###################################################
# 3.0 Work site setup group helper ################


###################################################
# 4.0 Session timeout warning #####################
sed -i "1120c timeoutDialogEnabled=true" $sakai_properties;
sed -i "1123c timeoutDialogWarningSeconds=600" $sakai_properties;

###################################################
# 5.0 Configure email #############################


###################################################
# 6.0 Configure logging ###########################


###################################################
# 7.0 Managing temporary files ####################


###################################################
# 6.1 Configure database ##########################
sed -i "311c username@javax.sql.BaseDataSource=`echo $usuariobd`" $sakai_properties;
sed -i "312c password@javax.sql.BaseDataSource=`echo $contrasena`" $sakai_properties;
sed -i "328c vendor@org.sakaiproject.db.api.SqlService=mysql" $sakai_properties;
sed -i "329c driverClassName@javax.sql.BaseDataSource=com.mysql.jdbc.Driver" $sakai_properties;
sed -i "330c hibernate.dialect=org.hibernate.dialect.MySQL5InnoDBDialect" $sakai_properties;
sed -i "331c url@javax.sql.BaseDataSource=jdbc:mysql://127.0.0.1:3306/`echo $basedatos`?useUnicode=true&characterEncoding=UTF-8" $sakai_properties;
sed -i "332c validationQuery@javax.sql.BaseDataSource=select 1 from DUAL" $sakai_properties;
sed -i "333c defaultTransactionIsolationString@javax.sql.BaseDataSource=TRANSACTION_READ_COMMITTED" $sakai_properties;

###################################################
##### Ejecucion de script en servidor mysql ####### # PENDIENTE POR DESARROLLAR Y VERIFICAR POLITICAS DE SEGURIDAD
###################################################
# echo "Creando la base de datos en MySql..."
# # ref http://clubmate.fi/shell-script-to-create-mysql-database/

# mysql -u root -p

# # Functions
# #ok() { echo -e '\e[32m'$1'\e[m'; } # Green

# MYSQL=`which mysql`
 
# Q1="create database ${basedatos} default character set utf8;"
# Q2="grant all on ${basedatos}.* to ${usuariobd}@'localhost' identified by '${contrasena}';"
# Q3="grant all on ${basedatos}.* to ${usuariobd}@'127.0.0.1' identified by '${contrasena}';"
# Q4= "flush privileges;"

# SQL="${Q1}${Q2}${Q3}${Q4}"

# $MYSQL -u root -p -e "$SQL"

# create database sakai10db default character set utf8;
# grant all on sakai10db.* to sakai10user@'localhost' identified by 'MysqlP.10L#2016';
# grant all on sakai10db.* to sakai10user@'127.0.0.1' identified by 'MysqlP.10L#2016';
# flush privileges;


echo "Ajustando los permisos y propiedades de archivos..."
echo " "
# Verificar permisos y propiedades
chown -R $usuario:$usuario ${Particion}/tomcat && chmod -R 775 ${Particion}/tomcat;
chown -R $usuario:$usuario ${Particion}/sakai-10.7 && chmod -R 775 ${Particion}/sakai-10.7;
chown $usuario:$usuario -R ${Particion}/apache-tomcat-8.0.36/ && chmod -R 775 ${Particion}/apache-tomcat-8.0.36;

# Borrando archivos innecesarios
echo "Borrando archivos que no son necesarios..."
echo " "
cd ${Particion};
rm -r jdk-7u80-linux-x64.tar.gz mysql-connector-java-5.1.39.tar.gz apache-tomcat-8.0.36.tar.gz  apache-tomcat-8.0.36.tar.gz.sha1 mysql-connector-java-5.1.39;


# arranque de la aplicacion
#su $usuario cd ${Particion}/tomcat/bin;
#su $usuario ./startup.sh && tail -f ../logs/catalina.out;

echo "Listo.  ;)"
####################################################
# Referencias
# http://unix.stackexchange.com/questions/148967/how-to-use-a-shell-variable-inside-seds-s-command